<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_belajar extends CI_Controller {

  // model digunakan untuk database sebagai CRUD

  function __Construct() {
    parent::__construct();
    $this->load->database();
  }

  function model_showdata() {
    $data_access = $this->db->get("users");

    if($data_access->num_rows() > 0) {
      return $data_access->result_array();
    } else {
      return false;
    }
  }


}

?>
