<?php

class Algorithm // ini object
{
  //ini property
  public $data; // membaca data CSV nya
  public $dataCluster; // menampung kumpulan jenis weather berdasarkan kondisinya
  public $cluster;

  public function readCSV($fileCsv) : self  //self difungsikan untuk mengembalikan berupa object
  {                                         // ini method, ada banyak versi, misal void / self / integer
    $data = [];           //tampungan untuk line ke 17 ($data[] {} itu)
    $handler = fopen($fileCsv, 'r');
    $i = 0;
    while($row = fgetcsv($handler, 2048)) :
      if ($i != 0) :
        $data[] = [
          'temp'        => $row[0],
          'hum'         => $row[1],
          'windspeed'   => $row[2],
          'pressure'    => $row[3],
          'cond'        => $row[4],
        ];
      endif;

      $item = [       //tampungan baru untuk mendefinisikan conditions dalam klasifikasinya
        'temp'        => $row[0],
        'hum'         => $row[1],
        'windspeed'   => $row[2],
        'pressure'    => $row[3],
        'cond'        => $row[4],
      ];

      for ($i=0; $i < 4 ; $i++) {
          if (in_array($row[4], ['Haze','Fair'])) {
            $cluster['Sunny'][] = $item;
          } else if (in_array($row[4], ['Partly Cloudy', 'Mostly Cloudy'])) {
            $cluster['Cloudy'][] = $item;
          } elseif (in_array($row[4], ['Thunder'])) {
            $cluster['Thunderstorm'][] = $item;
          } elseif (in_array($row[4], ['Light Rain'])) {
            $cluster['Rain'][] = $item;
          }
      }

      // echo "<pre>";print_r($cluster);die();

      if (in_array($row[4], ['Haze', 'Fair'])) :    //in_array digunakan untuk mengecek data didalam array ada atau tidak
        $cluster['Sunny'][] = $item;
      elseif (in_array($row[4], ['Partly Cloudy', 'Mostly Cloudy'])) :
        $cluster['Cloudy'][] = $item;
      elseif (in_array($row[4], ['Thunder'])) :
        $cluster['Thunderstorm'][] = $item;
      elseif (in_array($row[4], ['Light Rain'])) :
        $cluster['Rain'][] = $item;
      endif;

      $i++;
    endwhile;
//  mengambil property dari object menggunakan $this->*sesuai property diawal*
    $this->data = $data;  //data dari line 17 dimasukkan kedalam variable $data
    $this->dataCluster = $cluster;  //data $cluster dimasukkan ke dalam variable $dataCluster

    return $this;   //untuk me-return object itu sendiri
  }

  public function run() {
    $this->clustering();
    $this->iteration();
  }

  public function clustering() {
    $cluster = [];

    foreach ($this->dataCluster as $item) : //berupa value array
      $key = array_rand($item);   //random value array didalam $key
      $cluster[] = $item[$key];   //memanggil key nya (secara random dari arrray_rand($item))
    endforeach;

    $this->cluster = $cluster;
    // echo "<pre>";print_r($cluster);die();
  }

  public function iteration() {     //Eucledian Distance
    $data = [];
    foreach ($this->data as $dKey => $item) : //menggunakan key
      foreach ($this->cluster as $cKey => $cluster) :
        $jumlah[$dKey][$cKey] = pow($cluster['temp'] - $item['temp'], 2) + pow($cluster['hum'] - $item['hum'], 2) + pow($cluster['windspeed'] - $item['windspeed'], 2) + pow($cluster['pressure'] - $item['pressure'], 2);
        $rumus[$dKey][$cKey] = sqrt($jumlah[$dKey][$cKey]);
      endforeach;
      $clusterNumber = array_keys($rumus[$dKey], min($rumus[$dKey]));

      $item['cluster'] = $clusterNumber[0] + 1;
      $data[] = $item;
    endforeach;

    echo "<pre>";print_r($data);die();
  }
}
