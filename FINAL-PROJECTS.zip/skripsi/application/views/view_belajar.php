<!DOCTYPE HTML>
<html>
  <head>
    <title> WEATHER CLASSIFICATION USING K-MEANS ALGORITHM </title>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>assets/css/style.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
   <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
  </head>

  <body>
    <!-- <center>
        <?php
        // echo heading($title,2); ?>

        <center><input type="file" name="temperature" accept="text/csv"></center>
        <?php
        // echo br(2); ?>
        <button type="button" name="import">Import Data</button>
        <?php
            // echo br(2);
            // echo heading($tutorial,3);
            // echo heading($contains,3);
        ?>
        <?php //echo heading("K-Means Algorithm",6); ?> -->
    <!-- </center> -->
    <table id="example" >
      <thead>
          <tr>
            <th>iduser</th>
            <th>username</th>
            <th>password</th>
            <th>email</th>
            <th>jeniskelamin</th>
          </tr>
      </thead>
      <tbody>
        <?php foreach ($user as $key): ?>
          <tr>
            <td><?php echo $key['iduser']; ?></td>
            <td><?php echo $key['username']; ?></td>
            <td><?php echo $key['password']; ?></td>
            <td><?php echo $key['email']; ?></td>
            <td><?php echo $key['jeniskelamin']; ?></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
      <tfoot>
          <tr>
              <th>iduser</th>
              <th>username</th>
              <th>password</th>
              <th>email</th>
              <th>jeniskelamin</th>
          </tr>
      </tfoot>
  </table>

<script type="text/javascript">
  $(document).ready(function() {
    $('#example').DataTable();
  } );
</script>

<?php echo br(15) ?>
    <footer>
			<center><a href="https://www.instagram.com/axelwang_">15.K1.0007</a></center>
		</footer>


  </body>

</html>
