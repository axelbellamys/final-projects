<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!DOCTYPE HTML>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css"> -->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css')?>">
    <script src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js')?>"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <!-- <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script> -->
    <title> PROCESS RESULTS </title>
  </head>
  <body>
    <div class="container">
      <center<h1> K-MEANS CLUSTERING </h1></center>
      <div class="card">
        <div class="card-header">
          <div class="col-md-6">
            CONTROL ITERATION
          </div>
          <div class="col-md-6">
            <a href="<?php echo base_url('belajar/results') ?>"> RESULTS </a>
          </div>

        </div>
        <div class="card-body">
          <div class="row">
            <div class="col-md">
              <form action="" method="GET">
                <div class="form-group">
                  <label for="typeAttribute">Attribute</label>
                  <select class="form-control" name="selectAttribute" id="typeAttribute">
                    <option value="1" <?php echo $attributeKey == 1 ? "selected":'' ?>>Temperature</option>
                    <option value="2" <?php echo $attributeKey == 2 ? "selected":'' ?>>Dew Point</option>
                    <option value="3" <?php echo $attributeKey == 3 ? "selected":'' ?>>Humidity</option>
                    <option value="4" <?php echo $attributeKey == 4 ? "selected":'' ?>>Wind Speed</option>
                    <option value="5" <?php echo $attributeKey == 5 ? "selected":'' ?>>Pressure</option>
                    <option value="6" <?php echo $attributeKey == 6 ? "selected":'' ?>>PreciIntensity</option>
                    <option value="7" <?php echo $attributeKey == 7 ? "selected":'' ?>>PreciProbability</option>
                    <option value="8" <?php echo $attributeKey == 8 ? "selected":'' ?>>ApparentTemperature</option>
                    <option value="9" <?php echo $attributeKey == 9 ? "selected":'' ?>>WindGust</option>
                    <option value="10" <?php echo $attributeKey == 10 ? "selected":'' ?>>WindBearing</option>
                    <option value="11" <?php echo $attributeKey == 11 ? "selected":'' ?>>CloudCover</option>
                    <option value="12" <?php echo $attributeKey == 12 ? "selected":'' ?>>UVIndex</option>
                    <option value="13" <?php echo $attributeKey == 13 ? "selected":'' ?>>Visibility</option>
                    <option value="14" <?php echo $attributeKey == 14 ? "selected":'' ?>>Ozone</option>
                  </select>
                </div>
                <button type="submit" class="btn btn-success">SUBMIT</button>
              </form>
            </div>
            <div class="col-md">
              <p>
                Attribute : <?php echo $attribute[$attributeKey-1]; ?>
              </p>
              <p>
                Iterasi : <?php echo $iterasi; ?>
              </p>
              <p>
                <?php if ($iterasi>1): ?>
                  <a href="<?php echo base_url("belajar/showdata?selectAttribute=$attributeKey&iterasi=".($iterasi-1)) ?>" type="button" class="btn btn-primary"> PREV </a>
                <?php endif; ?>
                <?php if ($iterasi < $max_iterasi): ?>
                  <a href="<?php echo base_url("belajar/showdata?selectAttribute=$attributeKey&iterasi=".($iterasi+1)) ?>" type="button" class="btn btn-warning"> NEXT </a>
                <?php endif; ?>
              </p>
            </div>
          </div>
        </div>
      </div>
      <div class="card">
        <div class="card-header">
          RESULTS
        </div>
        <div class="card-body">
          <div class="row">
            <div class="col-md">
              <h5> DATA CENTROID </h5>
              <table class="table">
                <thead>
                  <tr>
                    <th>Centroid</th>
                    <th>Time</th>
                    <th><?php echo $attribute[$attributeKey-1] ?></th>
                  </tr>
                </thead>
                <tbody>
                  <?php $cluster = []; foreach ($centroidList as $keyCentroid => $centroid): ?>
                    <tr>
                      <td>C<?php echo $keyCentroid+1 ?></td>
                      <td><?php echo $centroid[0] ?></td>
                      <td><?php echo round($centroid[1],3) ?></td>
                    </tr>
                  <?php $cluster[] = $keyCentroid+1; endforeach; ?>
                </tbody>
              </table>
            </div>

            <div class="col-md-12">
              <h5> DATA CLUSTER </h5>
              <div class="row">
                <?php $i = 0; foreach ($clusterMembers as $keyCluster => $valueMembers): ?>
                  <div class="col-md-4">
                  <h6>Cluster <?php echo $cluster[$i]; ?></h6>
                  <table class="table">
                    <thead>
                      <tr>
                        <th>No</th>
                        <th>Time</th>
                        <th><?php echo $attribute[$attributeKey-1] ?></th>
                        <th>Cuaca</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php foreach ($valueMembers as $keyMember => $member): ?>
                          <tr>
                            <td><?php echo $keyMember+1 ?></td>
                            <td><?php echo $member[0] ?></td>
                            <td><?php echo $member[1] ?></td>
                            <td><?php echo $member[2] ?></td>
                          </tr>
                      <?php endforeach; ?>
                      <tr>
                        <td colspan="3">Kesimpulan</td>
                        <td><?php echo $clusterCuaca[$keyCluster] ?></td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <?php $i++; endforeach; ?>
              </div>
              <h5> CHART </h5>
              <div id="chartContainer" style="height: 1780px; width: 100%;"></div>
            </div>
          </div>
        </div>

      </div>

    </div>

  </body>
</html>
<script src="https://canvasjs.com/assets/script/jquery.canvasjs.min.js"></script>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
<script type="text/javascript">
  var centroid = JSON.parse('<?php echo $centroidJSON; ?>');
  var clusterMembers = JSON.parse('<?php echo $clusterMembersJSON ?>');
  var minmax = JSON.parse('<?php echo $minmax; ?>');
  var color = ["red","green","blue","yellow","cyan","orange","magenta","purple","brown","black","dimgray","chocolate","Silver","Ivory"];
  // console.log(clusterMembers);
  console.log(minmax);

  var dataChart = [];       //untuk menampung data grafik per attribute

 window.onload = function () {

   // GENERATE DATA FOR CHART
   clusterMembers.forEach((clusters,index) => {       // menyiapkan data per cluster (all) untuk canvas JS
     clusters = clusters.map(coord => {             // per data di ubah menjadi x dan y menggunakan function map
       return {x:parseFloat(coord[0]),y:parseFloat(coord[1])}     // x dan y nya
     });

     var objData = {
       axisYType: "primary",
       type: "scatter",
       color: color[index],
       dataPoints: clusters              // mengalokasikan per cluster
     }

     dataChart.push(objData);         // dimasukkan dalam array of chart
   });

   // GENERATE DATA FROM CENTROID FOR Chart
   centroid = Object.values(centroid).map(coord => {
     return {x:parseFloat(coord[0]),y:parseFloat(coord[1])}
   });

  centroid.forEach((node,index) => {        // ngeloop 1 per 1 centroid nya ([x,y] load 1, [x,y] load 1 lagi) , node pertama diubah warna nya , masukkan ke data chart,
    var objData = {
      axisYType: "primary",
      markerType: "cross",
      type: "scatter",
      markerSize:10,
      color: color[index],
      dataPoints:[node]
    }
    dataChart.push(objData);        // yang kedua buat object ubah warna masukin data chart
  })

   // CANVAS JS
   var chart = new CanvasJS.Chart("chartContainer",
   {
     title:{
       text: "Time - <?php echo $attribute[$attributeKey-1] ?>"
     },
     axisY: {
       title: "<?php echo $attribute[$attributeKey-1] ?>",
       viewportMaximum:minmax.max,
       viewportMinimum:minmax.min,
       interval:1
     },
     axisX: {
       title: "Time",
       interval:1
       // viewportMaximum:30,
     },
     // width:100,
     data: dataChart
   });
   // chart.datasets[0].points[2].fillColor = "#000";
   chart.render();
 }
 </script>
