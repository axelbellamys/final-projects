    <head>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
    <!-- <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script> -->
    </head>
    <center>
        <h1><center>Welcome !</center></h1>
        <form action="<?php echo base_url('belajar/newCentroid') ?>" method="POST" enctype="multipart/form-data">
          Input K Here : <input type="text" name="jumlahka">
          <button type="submit">Submit</button>
        </form>
        <?php echo br(4); ?>

        <table id="example">
        	<thead>
        		<tr>
              <th>Time</th>
              <th>Summary</th>
              <th>PrecipIntensity</th>
              <th>PrecipProbability</th>
        			<th>Temperature</th>
        			<th>Apparent Temperature</th>
        			<th>Dew Point</th>
              <th>Humidity</th>
        			<th>Pressure</th>
              <th>Wind Speed</th>
              <th>Wind Gust</th>
              <th>Wind Bearing</th>
              <th>Cloud Cover</th>
              <th>UV Index</th>
              <th>Visibility</th>
              <th>Ozone</th>
        		</tr>
        	</thead>
        	<tbody>
            <?php foreach ($currentData as $valueData): ?>
              <tr>
                <td><?php echo $valueData['time'] ?></td>
                <td><?php echo $valueData['summary'] ?></td>
                <td><?php echo $valueData['precipIntensity'] ?></td>
                <td><?php echo $valueData['precipProbability'] ?></td>
                <td><?php echo $valueData['temperature'] ?></td>
                <td><?php echo $valueData['apparentTemperature'] ?></td>
                <td><?php echo $valueData['dewPoint'] ?></td>
                <td><?php echo $valueData['humidity'] ?></td>
                <td><?php echo $valueData['pressure'] ?></td>
                <td><?php echo $valueData['windSpeed'] ?></td>
                <td><?php echo $valueData['windGust'] ?></td>
                <td><?php echo $valueData['windBearing'] ?></td>
                <td><?php echo $valueData['cloudCover'] ?></td>
                <td><?php echo $valueData['uvIndex'] ?></td>
                <td><?php echo $valueData['visibility'] ?></td>
                <td><?php echo $valueData['ozone'] ?></td>
              </tr>
            <?php endforeach; ?>

        	</tbody>
        </table>

    </center>

    <script type="text/javascript">
      $(document).ready(function() {
        $('#example').DataTable();
      } );

      function retrieveData() {
        $.ajax({
          url: "Belajar/index", //the page containing php script
          type: "post", //request type,
          dataType: 'json',
          data: {},
          success:function(result) {
            console.log(result.abc);
          }
        });
      }

    </script>
