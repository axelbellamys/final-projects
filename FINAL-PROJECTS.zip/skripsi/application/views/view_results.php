<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css')?>">
    <script src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js')?>"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <title>RESULTS</title>
  </head>
  <body>
    <div class="container">
      <br>
      <center><h1>RESULTS WEATHER CONDITION</h1></center>
      <br>
      <br>
      <table class="table table-bordered">
        <thead>
          <tr>
            <th>Attribute</th>
            <th>Weather</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($weatherByAttribute as $attr => $weather): ?>
            <tr>
              <td><?php echo $weatherNames[$attr - 1]; ?></td>
              <td><?php echo $weather; ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
      <h3><center>The conclusion of the data above is <strong> <?php echo $weatherResult; ?> </strong></center></h3>
      <hr>
      <br>
      <br>
    </div>
  </body>
</html>
