<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

<!DOCTYPE HTML>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/bootstrap/css/bootstrap.min.css')?>">
    <script src="<?php echo base_url('assets/bootstrap/js/bootstrap.min.js')?>"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>

    <title>TAMPIL CENTROID</title>
  </head>
  <body>
    <div class="container">
      <center><h1>LIST CENTROID</h1></center><br>
      <div class="row">

        <?php foreach ($listCentroid as $listKey => $valueRow): ?>     <!-- untuk loop daftar attribute, $listCentroid isinya adalah daftar attribute,$listKey isinya key dari attribute  tsb, $valueRow isinya daftar centroid -->
          <div class="col-md-3">
              <h5>Centroid untuk Attribute <?php echo $attribute[$listKey-1]; ?></h5>
              <table class="table">
                <thead>
                  <tr>
                    <th width="30px">Centroid</th>
                    <th>Time</th>
                    <th><?php echo $attribute[$listKey-1]; ?></th>
                  </tr>
                </thead>

                <tbody>
                  <?php foreach ($valueRow as $valKey => $valueAttribute) : ?>
                    <tr>
                      <td>C<?php echo $valKey+1; ?></td>
                      <td><?php echo $valueAttribute[0]; ?></td>
                      <td><?php echo $valueAttribute[1]; ?></td>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
          </div>
        <?php endforeach; ?>
      </div>
    </div>

    <?php echo br(2); ?>
    <form>
      <center>
        <input type="button" value="PROCESS" onclick="window.location.href='<?php echo base_url('belajar/processCentroid') ?>'" />
      </center>
    </form>

    <!-- <center><a href="<?php echo base_url('belajar/processCentroid') ?>" type="submit" name="loadkmeans"> PROCESS </a></center> -->

  </body>
</html>
<!-- <script type="text/javascript">
  $(document).ready(function() {
    $('#random').DataTable();
  } );
</script> -->
