<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tes extends CI_Controller {

  public function index() {
    $this->load->library('Algorithm');

    $alg = new Algorithm;       //FCPATH ada di user guide untuk digunakan mengambil file dari sub folder csv, folder asli yaitu 'les'
    $alg->readCSV(FCPATH . 'csv/2016.csv')->run();  //bisa digunakan untuk mengambil object lagi jika di return
    // echo "<pre>";print_r($alg);die();
  }

  public function newCentroid() {
    $data = [];
    $i = 0;
    // $csv = [];
    // $list = [];

    if (isset($_POST['jumlahka'])) {

      $file = file('csv/2016.csv');
      foreach ($file as $k) {
        $csv[] = explode('.',$k);
      }

      // echo "<pre>";print_r($csv);die();
      // echo sizeof($csv);
      for ($x = 1; $x <= $_POST['jumlahka']; $x++) {
        // echo();
        echo $csv[rand(1,sizeof($csv))][0];
        echo "                   ";
        echo $csv[rand(1,sizeof($csv))][1];
        echo "<br>";
      }
    }
  }
}
