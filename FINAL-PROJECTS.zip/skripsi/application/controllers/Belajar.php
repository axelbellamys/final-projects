<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Belajar extends CI_Controller {

  public $csvFile = 'csv/weather.csv';

  public function __construct() {
		parent::__construct();
	}

  public function index() {
    $forecast = $this->readFromCSV();

    $data['currentData'] = $forecast;
    // $this->mauliat($data);
    $this->load->view('index',$data);

  }

  public function readFromCSV()
  {
    $handler = fopen($this->csvFile, 'r');

    $csv = [];
    $i = 0;
    while ($row = fgetcsv($handler, 2048)) {
      if ($i == 0) {
        $column = $row;             //baris pertama dijadikan unique key dalam menentukan atribut yang lain
      } else {
        $_data = [];
        foreach ($row as $key => $data) {           //memasukkan data atribut sesuai dengan urutan key dan valuenya
          $_data[$column[$key]] = $data;
        }
        $csv[] = $_data;
      }

      $i++;
    }

    return $csv;
  }

  function readWeatherDataFromCSV($namafile) {
    // $fileCsv = 'csv/' . $_POST['file_csv'];
    $handler = fopen($namafile, 'r');
    $csv = [];

    while($row = fgetcsv($handler, 2048)) {     //memproses data csv

      $csv[] = [
        (int) date('H', strtotime($row[0])),
        $row[4],
        $row[6],
        $row[7],
        $row[9],
        $row[8],
        $row[2],
        $row[3],
        $row[5],
        $row[10],
        $row[11],
        $row[12],
        $row[13],
        $row[14],
        $row[15],
        $row[1]
      ];
    }     //ubah cronjob, data csvnya kolom disesuaikan
    // $this->mauliat($csv);
    return $csv;
  }

  public function newCentroid() {

    if (!isset($_POST['jumlahka'])) {    //|| !isset($_POST['file_csv']
      alert("Jumlah centroid belum dimasukkan!");       //kosongan
      exit();
    }

    $csv = $this->readWeatherDataFromCSV($this->csvFile);   //. $_POST['file_csv']);

    // TENTUKAN MAKSIMUM & MINIMUM SELURUH ATRIBUTE;
    $max = [];
    $min = [];

    array_shift($csv);
    $totalVariable = count($csv[0]) - 1;
    // $this->mauliat($totalVariable);

    for ($i = 0; $i < $totalVariable; $i++) {
      $min[$i] = floor(min(array_column($csv, $i)));
      $max[$i] = floor(max(array_column($csv, $i)));
    }

    $this->saveMinMaxVariable($min, $max);

    // foreach ($csv as $key => $dataRow) {          //memisah dan looping per baris dari data CSV yang terpilih
    //   if($key == 0) continue;
    //   // $this->mauliat($dataRow);
    //   foreach ($dataRow as $attrKey => $attributeValue) {     //dari per baris, dipecah menjadi per attribute
    //     if($attrKey == 6) break;
    //     // $this->mauliat($attributeValue);
    //     if(!isset($max[$attrKey]) || $max[$attrKey] < $attributeValue)    //jika tidak kosong || mengisi value apabila ada yang lebih besar dari value sebelumnya
    //       $max[$attrKey] = $attributeValue;
    //
    //     if(!isset($min[$attrKey]) || $min[$attrKey] > $attributeValue)
    //       $min[$attrKey] = $attributeValue;                               //sebaliknya, jika ditemukan yg lebih kecil, maka di tampung dalam variable $min[$attrkey]
    //   }
    // }

    // $this->mauliat($_POST['jumlahka']);
    // RANDOM PROCESS PER ATTRIBUTE BEGINS HERE
    // $this->mauliat($max);
    for ($i=1; $i < count($max); $i++) {  // LOOP SEMUA ATRIBUT KECUALI YANG PERTAMA (TIME), biar ga bablas dikasi count(%max)
      for ($j=0; $j < $_POST['jumlahka']; $j++) { // LOOP UNTUK JUMLAH CENTROID
        $listCentroid[$i][] = [rand($min[0],$max[0]),rand($min[$i],$max[$i])];     // [0] UNTUK TIME, DAN [$i] UNTUK PER ATRIBUT
        // $listCentroid[$i][0] = [8,90];
        // $listCentroid[$i][1] = [12,80];
        // $listCentroid[$i][2] = [18,85];
        // $listCentroid[$i][3] = [21,78];
      }
    }
    // END OF RANDOM PROCESS
    // $this->mauliat($listCentroid);

    $this->saveCentroidNew($listCentroid,'logfile/centroid.txt');
    $attribute = ['Temperature','Dew Point','Humidity','WindSpeed','Pressure','PreIntensity','PreProbability','ApparTemperature','WindGust','WindBearing','CloudCover','UVIndex','Visibility','Ozone'];     //mendefinisikan untuk seluruh nama attribute
    $this->load->view('view_centroid', [
      'listCentroid'    =>  $listCentroid,
      'attribute'       =>  $attribute
    ]);
  }

  public function saveMinMaxVariable($min, $max)
  {
    $dataMin = implode(',', array_map(function($nilai){
      $min = $nilai - 2;

      if ($min <= 0) {
        return 0;       //jika min nya minus , maka dibatasi dibuat menjadi 0 saja
      } else {
        return $min;    // jika tidak maka di sesuaikan dengan min nya
      }
    }, $min));

    $dataMax = implode(',', array_map(function($nilai) {
      return($nilai + 2);
    }, $max));

    $logContent = $dataMin . ";" . $dataMax;

    file_put_contents('logfile/minmax.txt', $logContent);
  }

  public function readMinMaxVariable($attribute = 1)
  {
    $content = file_get_contents('logfile/minmax.txt');
    $explode = explode(';', $content);

    return [
      'min' => explode(',', $explode[0])[$attribute],
      'max' => explode(',', $explode[1])[$attribute],
    ];
  }

  function saveCentroidNew($centroidList,$namafile) {
    $contentFile = [];

    foreach ($centroidList as $key => $attributeName) {              // loop all list atribut (mulai dari temperature dst)
      $attributeData = [];

      foreach ($attributeName as $keyCentroid => $centroid) {       //loop all list centroid
        array_unshift($centroid,$keyCentroid);                      // menambahkan element didalam array pada urutan pertama
        $attributeData[]  = implode(',',$centroid);                   //dimana setiap menemukan X dan Y , mereka disatukan jadi 1 string dengan pemisah ,
      }

      $contentFile[] = implode(';',$attributeData);                 //lalu di gabungkan lagi menjadi 1 bagian attribute dan dipisahkan dengan ;
    }
    $contentFile = implode("\n",$contentFile);                      //seluruh list centroid berhasil digabungkan, dipisahkan dengan enter
    file_put_contents($namafile,$contentFile);
  }

  function readFirstCentroidFromTxt($namafile) {
    $content = file_get_contents($namafile);
    $content = explode("\n",$content);
    $result = [];
    // $this->mauliat($content);
    foreach ($content as $key => $value) {
      $result[$key+1] = explode(";",$value);          // +1 agar dimulai dari 1 (temp, dst)

      foreach ($result[$key+1] as $key2 => $value2) {
        $explodedCentroid = explode(",",$value2);       // yg awalnya 10,78 jadi 10 dan 78 terpisah
        $keyCentroid = $explodedCentroid[0];            // index ke 0 (isinya nilai unshift ditampung biar ga ilang total)
        array_shift($explodedCentroid);                 //terus diilangin
        $result[$key+1][$keyCentroid] = $explodedCentroid;      // nah yg jadi unshiftan tadi itu ditampung dalam sini
      }
    }
    return $result;
  }

  public function processCentroid() {
    // GET FIRST CENTROID
    // $newcontent = file_get_contents('logfile/centroid.txt');    //WE USED THE INPUTED CENTROID FROM USER
    // $newcontent = explode("\n",$newcontent);      //DIPISAHKAN , 1 ARRAY DI ENTER, 1 ARRAY LAGI DI ENTER

    $centroidData = $this->readFirstCentroidFromTxt('logfile/centroid.txt');
    // $this->mauliat($centroidData);
    $dataCSV = $this->readWeatherDataFromCSV($this->csvFile);
    array_shift($dataCSV);                  // menghapus baris pertama
    // $this->mauliat($dataCSV);
    $allResult = [];
    $max_iterasi = [];

    // echo "ALL CENTROID <BR>";
    // $this->mauliat($centroidData);
    foreach ($centroidData as $key => $centroidForAttribute) {      // centroidForAtributter berisi list centroid dari attribute yang sedang di loop
      // echo "CENTROID FOR ATTRIBUTE <br>";
      // $this->mauliat($centroidForAttribute);
      $allResult[$key] = $this->kMeans($centroidForAttribute,$dataCSV,$key);      //$key =  attributenya
      $max_iterasi[$key] = $allResult[$key]['max_iterasi'];         // menampung maksimum iterasi dari perhitungan k means untuk attribute ke $key (tertentu)
    }
    // $this->mauliat($allResult);        //ada iterasi didalam per attribute
    // SAVING MAX Iterasi
    ksort($max_iterasi);

    $contentMaxIterasi = implode(';',$max_iterasi);

    file_put_contents('logfile/maxiterasi.txt',$contentMaxIterasi);
    // $this->mauliat($allResult);
    redirect(base_url('belajar/showData'));   // pindah ke show data
  }

  //CALCULATION BEGINS HERE
  function kMeans($centroidList,$dataCSV,$columnTarget)         //COLUMN TARGETNYA urut temp dulu, lalu dew, lalu hum, dst
  {
      // return [$centroidList,$columnTarget,$dataCSV];
      // $this->mauliat($centroidList,false);
      $currentCentroidList = $centroidList;                          //SAVING EVERY NEW CENTROID
      $iterasiKMean = 0;                                  //DEFINITION FOR EACH CALCULATION RESULT
      $convergence = false;
      $viewData = [];
      $this->saveCentroidList($currentCentroidList,'logfile/newCentroid_Attribute_'.$columnTarget."_Iterasi_1.txt");

      // STARTING KMEANS LOOP
      while(!$convergence && $iterasiKMean < 100) {
        $iterasiKMean += 1;

        // CALCULATE DISTANCE MATRIX FOR ALL DATA FROM EACH CENTROID
        $distanceMatrix = [];
        foreach ($dataCSV as $dKey => $data) {  // seluruh sumber data di loop
          foreach ($currentCentroidList as $cKey => $centroid) {   // loop centroid inputan user
            $jumlah = 0;
            $jumlah = pow(($centroid[0] - $data[0]),2) + pow(($centroid[1]-$data[$columnTarget]),2);   // CENTROID[0] ITU ATRIBUT TIME DARI CENTROID, $DATA[0] ITU ATRIBUT TIME DARI DATA
            $distanceMatrix[$dKey][$cKey] = sqrt($jumlah);  //baru diakar
          }
        }
        // echo "Distance Matrix: ";
        // $this->mauliat($currentCentroidList,false);
        // $this->mauliat($dataCSV,false);
        // $this->mauliat($distanceMatrix);
        // CHECKING V1 it works well
        // END OF CALCULATE DISTANCE MATRIX FOR ALL DATA FROM EACH CENTROID

        // SAVE CALCULATION FIRST CENTROID
        $this->saveCalculationMatrix($distanceMatrix,"logfile/distanceMatrix_Attribute_".$columnTarget."_Iterasi_".$iterasiKMean.".txt");
        // END OF SAVE CALCULATOIN FIRST CENTROID

        // EXTRACT CLUSTERS (SEARCH MINIMUM)
        $clusterMembers = [];
        foreach ($distanceMatrix as $key => $value) {   //setiap loop diliat minimum nya
          $min = min($value);                 //ambil minimum dari seluruh distance terhadap centroid
          // $distanceMatrix[$key]['min'] = $min;      //  ['min'] itu sekadar nama untuk mencatat nilai minimal dalam $min
          // $distanceMatrix[$key]['indexCentroid'] = array_search($min,$value); // ['indexCentroid'] itu sekadar nama untuk mencari index dari value $min (atau minimum)
          $indexCentroid = array_search($min, $value); // ['indexCentroid'] itu sekadar nama untuk mencari index dari value $min (atau minimum)
          // $thise[] = [$columnTarget, $dataCSV[$key], $distanceMatrix[$key], $min, $indexCentroid];
          $clusterMembers[$indexCentroid][] = [$dataCSV[$key][0],$dataCSV[$key][$columnTarget],$dataCSV[$key][15]];   //index pertama ($key) masuk ke $clusterMembers, mengelompokkan berdasarkan ada tidaknya data di masing" clusters
        }

        // $this->mauliat($clusterMembers[$indexCentroid]);
        $this->saveMembersList($clusterMembers,'logfile/clusterMembers_Attribute_'.$columnTarget."_Iterasi_".$iterasiKMean.'.txt');
        // $this->mauliat([$iterasiKMean, $thise, $clusterMembers]);
        // END OF EXTRACT CLUSTERS (SEARCH MINIMUM)

        // echo "CLUSTER MEMBER: ";
        // if($iterasiKMean == 2)
        //   $this->mauliat($clusterMembers);

        // GENERATE NEW CENTROID FROM CLUSTERED DATA
        $newCentroid = [];
        foreach ($clusterMembers as $cKey => $cMembers) {   //mengulang seluruh anggota cluster yang terpilih
          $newCentroid[$cKey] = [];                       //variable centroid baru berdasarkan key yang terpilih
          $jumlahMember = count($cMembers);
        // END OF GENERATE NEW CENTROID FROM CLUSTERED DATA

          // MENGHITUNG PENJUMLAHAN UNTUK MASING MASING NILAI ATRIBUTE UNTUK CENTROID BARU
          foreach ($cMembers as $mKey => $dataRowMember) {          // per baris masing" cluster

            foreach ($dataRowMember as $attrKey => $attributeMember) {      //per atribut masing" cluster
              if($attrKey == 2) { // skip untuk data kondisi cuaca
                break;
              }
              if(!isset($newCentroid[$cKey][$attrKey]))       // !isset = jika tidak ada isinya, $cKey karena keseluruhan data yg terpilih yg digunakan
                $newCentroid[$cKey][$attrKey] = $attributeMember;   //di isi dengan per nilai attribute (angkanya masing")
              else
                $newCentroid[$cKey][$attrKey] += $attributeMember;    // jika sudah ada, ditambahkan per nilai attributenya
            }
          }
          // END OF MENGHITUNG PENJUMLAHAN UNTUK MASING MASING NILAI ATRIBUTE UNTUK CENTROID BARU

          // $this->mauliat($newCentroid[$cKey]);

          // PEMBAGIAN UNTUK MASING MASING ATRIBUTE DI CENTROID
          foreach ($newCentroid[$cKey] as $key => $value) {
            $newCentroid[$cKey][$key] = $value/$jumlahMember;
          }
          // END OF PEMBAGIAN UNTUK MASING MASING ATRIBUTE DI CENTROID
        }
        // ksort($newCentroid);
        // if($iterasiKMean == 2)
          // $this->mauliat($newCentroid);          //bisa dilihat hasil pembagiannya disini

        // SAVING NEW CENTROID TO txt

        $this->saveCentroidList($newCentroid,'logfile/newCentroid_Attribute_'.$columnTarget."_Iterasi_".($iterasiKMean + 1).'.txt');
        // END OF SAVING NEW CENTROID TO txt


        // CHECK ERROR RATE (COMPARE)
        $convergence = true;        //ASSUME THAT ALREADY SIMILAR, THEN CHECKED ON FOREACH BELOW
        foreach ($newCentroid as $newKey => $new) {
          if(!empty(array_diff($new,$currentCentroidList[$newKey]))) {        //ARRAY_DIFF IS TO COMPARE AND FIND THE DIFFERENCES
            $convergence = false;                   // IF THERE ARE ANY DIFFERENCES, THEN BECOME FALSE, DO WHILE AGAIN
            $currentCentroidList = $newCentroid;    // LAST CENTROID BECOME THE NEW ONE FOR THE NEXT DISTANCE CALCULATION
            break;
          }
        }
        // END OF CHECK ERROR RATE

        ksort($clusterMembers);
        ksort($newCentroid);
        $result[] = [
          'clusterMembers'  =>  $clusterMembers,
          'centroid'        =>  $newCentroid,
        ];
      } // END OF WHILE
      $result['max_iterasi']  = $iterasiKMean;
      return $result;
  }


  public function showData() {
    $attributeKey = $this->input->get('selectAttribute') ? $this->input->get('selectAttribute') : 1;      //bentuk sederhana dari if , pengaruh di URL nya
    $iterasi = $this->input->get('iterasi') ? $this->input->get('iterasi') : 1;

    $max_iterasi = $this->readMaxIterasi();
    $centroidList = $this->readCurrentCentroidFromTxt("logfile/newCentroid_Attribute_".$attributeKey."_Iterasi_".$iterasi.".txt");
    $clusterMembers = $this->readCurrentMembersFromTxt("logfile/clusterMembers_Attribute_".$attributeKey."_Iterasi_".$iterasi.".txt");
    $distanceMatrix = $this->readDistanceMatrixFromTxt("logfile/distanceMatrix_Attribute_".$attributeKey."_Iterasi_".$iterasi.".txt");
    $clusterCuaca = $this->extractCuaca($clusterMembers);
    $minmax = $this->readMinMaxVariable($attributeKey);

    $data = [
      'attribute'     => ['Temperature','Dew Point','Humidity','WindSpeed','Pressure','PreIntensity','PreProbability','ApparTemperature','WindGust','WindBearing','CloudCover','UVIndex','Visibility','Ozone'],
      'attributeKey'  => $attributeKey,
      'iterasi'       => $iterasi,
      'centroidList'  => $centroidList,
      'clusterMembers'=> $clusterMembers,
      'clusterCuaca' => $clusterCuaca,
      'centroidJSON'  => json_encode($centroidList),
      'clusterMembersJSON'  => json_encode($clusterMembers),
      'max_iterasi'     =>  $max_iterasi[$attributeKey-1],
      'minmax'        => json_encode($minmax)
    ];
    $this->load->view('view_process',$data);
  }

  function extractCuaca($clusterMembers) {
    $clusterCuaca = [];
    foreach ($clusterMembers as $keyCluster => $valueCluster) {   //melakukan loop di setiap cluster nya
      $listCuaca = [];
      $countCuaca = [];
      foreach ($valueCluster as $keyMember => $valueMembers) {    //melakukan loop di setiap membersnya
        if(!in_array($valueMembers[2],$listCuaca))  {     // kalo belum ada kondisi cuaca di dalam $listCuaca
          $listCuaca[] = $valueMembers[2];              // maka dimasukkan ke $listCuaca
          $countCuaca[] = 1;                            // 1 untuk awalan supaya tidak error
        } else {
          $indexCuaca = array_search($valueMembers[2],$listCuaca);      // sebaliknya, jika sudah ada
          $countCuaca[$indexCuaca] += 1;                                // maka ditambahkan terus
        }
      }
      $maximum = max($countCuaca);     //menghitung nilai max dari $countCuaca;
      $indexMaximum = array_search($maximum,$countCuaca);     //index ke berapa yang maksimum?
      $maxCuaca = $listCuaca[$indexMaximum];      // nah indexnya dimasukkan ke dalam $listCuaca[], terus dicetak pake $maxCuaca
      $clusterCuaca[$keyCluster] = $maxCuaca;
    }

    return $clusterCuaca;
  }

  //SAVE MEMBERS TO EACH CLUSTER FROM THE MINIMUM SEARCH RESULTS
  public function saveCalculationMatrix($distanceMatrix,$namafile) {
    $contentCalculation = [];
    foreach ($distanceMatrix as $key => $valueDistance) {
      $contentCalculation[] = implode(',',$valueDistance);     //buat hasil perhitungan, gabungin array nya jadi 1
    }
    $contentCalculation = implode("\n",$contentCalculation);
    // $this->mauliat($contentCalculation);

    file_put_contents($namafile,$contentCalculation);
  }

  function saveMembersList($clusterMembers,$namafile) {
    ksort($clusterMembers);
    $contentMemberList = [];
    foreach ($clusterMembers as $clusKey => $valueMembers) { // MEMECAH PER CLUSTER
      $gabungData[$clusKey] = [];
      foreach ($valueMembers as $valKey => $specificMembers) { // MEMECAH PER DATA
        $gabungAttribut[$clusKey][$valKey] = implode(',', $specificMembers); // MEMECAH PER ATRIBUT
        $gabungData[$clusKey][$valKey] = $gabungAttribut[$clusKey][$valKey];
      }
      $gabungMember[$clusKey] = implode(';',$gabungData[$clusKey]);
      $contentMemberList[$clusKey] = $gabungMember[$clusKey];     // per cluster, ada proses penyimpanannya, supaya bisa dipisahkan dengan cluster yang lain
    }
    // $this->mauliat($contentMemberList);
    $contentMemberList = implode("\n",$contentMemberList);
    // $this->mauliat($contentMemberList);
    file_put_contents($namafile,$contentMemberList);

  }

  function saveCentroidList($centroidList,$namafile) {      //menyimpan centroid baru setelah diolah
      ksort($centroidList);
      $contentCentroidList = [];
      foreach ($centroidList as $key => $valueCentroid) {
        array_unshift($valueCentroid,$key);
        $contentCentroidList[] = implode(',',$valueCentroid);
      }
      $contentCentroidList = implode("\n",$contentCentroidList);
      // $this->mauliat($contentCentroidList);
      file_put_contents($namafile,$contentCentroidList);
  }

  function readMaxIterasi() {
      $content = file_get_contents('logfile/maxiterasi.txt');
      return explode(';',$content);
  }                             // menghitung maksimum iterasi

  function readDistanceMatrixFromTxt($namafile)         // pengolahan jarak baru dari txt
  {
    $file = file_get_contents($namafile);
    $file = explode("\n",$file);
    foreach ($file as $key => $value) {
      $file[$key] = explode(",",$value);
    }
    return $file;
  }

  function readCurrentCentroidFromTxt($namafile) {
    $contentNewCentroid = file_get_contents($namafile);
    $contentNewCentroid = explode("\n",$contentNewCentroid);
    $result = [];
    foreach ($contentNewCentroid as $conKey => $valueCentroid) {
      $explodedCentroid = explode(",",$valueCentroid);
      $centroidKey = $explodedCentroid[0];
      array_shift($explodedCentroid);
      $result[$centroidKey] = $explodedCentroid;
    }
    // $this->mauliat($result);

    return $result;
  }

  function readCurrentMembersFromTxt($namafile) {
    $contentNewMembers = file_get_contents($namafile);
    $contentNewMembers = explode("\n",$contentNewMembers);
    $result = [];
    foreach ($contentNewMembers as $memKey => $valueMembers) {
      $result[$memKey] = explode(";",$valueMembers);                    //memecah ; urut dari index 0, kemudian 1 , lalu 2 , dst
      foreach ($result[$memKey] as $valKey => $attributeMember) {
        $result[$memKey][$valKey] = explode(",",$attributeMember);      //dipecah jadi x dan y
      }
      // $this->mauliat($result);
    }
    return $result;
  }

  public function results() {
    $files = $this->getLastIterationFile();
    $weatherByCluster = $this->getWeatherByCluster($files);
    $weatherByAttribute = $this->getWeatherByAttribute($weatherByCluster);
    $weatherResult = $this->getWeatherResult($weatherByAttribute);            //prosesnya naik keatas

    $data['weatherResult'] = $weatherResult;
    $data['weatherByAttribute'] = $weatherByAttribute;
    $data['weatherNames'] = [
      "Temperature",
      "Dew Point",
      "Humidity",
      "Wind Speed",
      "Pressure",
      "PrecipIntensity",
      "PrecipProbability",
      "Apparent Temperature",
      "Wind Gust",
      "Wind Bearing",
      "Cloud Cover",
      "UV Index",
      "Visibility",
      "Ozone"
    ];
    // $this->mauliat($data['weatherNames']);

    $this->load->view('view_results', $data);
  }

  private function getWeatherResult($weatherByAttribute)
  {
    $mostWeathers = array_count_values($weatherByAttribute);
    asort($mostWeathers);
    end($mostWeathers);

    return key($mostWeathers);
  }

  private function getWeatherByAttribute($weatherByCluster)
  {
    $weatherByAttr = [];
    foreach ($weatherByCluster as $attr => $weathers) {
      $mostWeathers = array_count_values($weathers);
      asort($mostWeathers);
      end($mostWeathers);
      $weatherByAttr[$attr] = key($mostWeathers);
    }

    return $weatherByAttr;
  }

  private function getWeatherByCluster($files)
  {
    $data = [];
    $weatherAttr = [];
    foreach ($files as $attr => $file) {
      $_data[$attr] = $this->readCurrentMembersFromTxt("logfile/{$file}");
      foreach ($_data[$attr] as $cluster => $member) {
        $weathers = array_column($_data[$attr][$cluster], 2);   //untuk mencari weathernya dan menampungnya dari masing" cluster dan atribute
        $mostWeathers = array_count_values($weathers);    //untuk menghitung jumlah weather dari masing" atribute dan clusters
        asort($mostWeathers);     //array sort berdasarkan value secara ascending
        end($mostWeathers);     //  pointer ditunjuk diakhir
        $weatherAttr[$attr][$cluster] = key($mostWeathers);     //untuk mengambil key (kondisi cuaca) yang diakhir tersebut
      }
    }

    return $weatherAttr;
  }

  private function getLastIterationFile()
  {
    $scan = scandir('logfile');

    $files = [];
    foreach ($scan as $file) {
      if ($file == '.' || $file == '..') continue;

      $regex = '/^([a-zA-Z]+)[a-zA-Z_]+(\d+)[a-zA-Z_]+(\d+).txt/m';
      preg_match_all($regex, $file, $matches, PREG_SET_ORDER, 0);       //$files itu namafile yang di scan, $regex rule aturan pemisahnya, $matches adalah penampung matchingnya

      if (empty($matches) || $matches[0][1] != 'clusterMembers') continue;    //kalo tidak ada isinya dan bukan clusterMembers maka dilewati

      $files[$matches[0][2]][$matches[0][3]] = $file;     //$files menampung atribut (2) dan iterasi (3) , masing" atribut ada berapa banyak, dimasukkan kesitu
    }
    ksort($files);        //urutan berdasarkan atribute

    $fileNames = [];
    foreach ($files as $attribute => $file) {   // dipecah lagi untuk mendapatkan iterasi terakhir
      ksort($file);       //urutan berdasarkan atribute

      $fileNames[$attribute] = end($file);    //diambil iterasi yang terakhir menggunakan end()
    }

    return $fileNames;
  }


  function mauliat($data,$exit = true) {
    echo "<pre>";print_r($data);echo "</pre>";
    if($exit)
      exit();
  }
}



?>
