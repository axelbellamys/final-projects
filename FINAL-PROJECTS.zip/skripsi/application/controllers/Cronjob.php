<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cronjob extends CI_Controller {

  public $storage = "csv/weather.csv";

  public function __construct() {
    parent::__construct();

    if (!$this->input->is_cli_request()) show_error('Direct access is not allowed!');
  }

  public function weather() {
    $coordinates = ['-6.9932', '110.4203'];
    $api = 'https://api.darksky.net/forecast/568a0503ec1e51fca8e10496af04780d/';
    $request = $api . implode(',', $coordinates);

    $content = file_get_contents($request);

    $this->saveContent($content);
  }

  public function saveContent($content)
  {
    $weather = json_decode($content);

    foreach ($weather->hourly->data as $data) {
      $_value = [];
      foreach ($data as $key => $value) {
        if ($key == 'time') {
          $_value[] = date('Y-m-d H:i:s', $value);
        } else if ($key == 'precipType' || $key == 'icon') {
          continue;
        } else {
          $_value[] = $value;
        }
      }

      $collect[] = implode(',', $_value);
    }

    $result = implode("\n", $collect);

    file_put_contents($this->storage, $result.PHP_EOL , FILE_APPEND | LOCK_EX);
  }
}
