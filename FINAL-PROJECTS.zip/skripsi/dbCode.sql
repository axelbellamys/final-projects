DROP DATABASE IF EXISTS dbCode;
CREATE DATABASE dbCode;
USE dbCode;

CREATE TABLE users
(
  iduser int AUTO_INCREMENT PRIMARY KEY,
  username varchar(200),
  password varchar(100),
  email varchar(200),
  jeniskelamin varchar(15)
);

CREATE TABLE cuaca
(
  temperature int AUTO_INCREMENT PRIMARY KEY,
  humidity int,
  windspeed int,
  pressure double,
  kondisi varchar(255)
);

INSERT INTO users VALUES (NULL,'axelwang','abcdef','masterongaxel@gmail.com','PRIA'),
(NULL,'madelinevrgnia','abcdef','madeline@gmail.com','WANITA'),
(NULL,'eillenkalsitha','abcdef','eillenkalsitha@gmail.com','WANITA'),
(NULL,'yosicakaruni','abcdef','yosicakaruni@gmail.com','WANITA');
